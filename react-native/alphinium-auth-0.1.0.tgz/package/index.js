/**
 * @alphinium/auth — React Native entry point
 *
 * Usage in alphinium-app or any forge-generated project:
 *
 *   import { AuthProvider, useAuth, withAuth, LoginScreen } from '@alphinium/auth';
 *
 * Wrap your app with <AuthProvider strapiUrl="https://auth.alphinium.io">
 * then use useAuth() or withAuth(Component) anywhere inside it.
 */

export { AuthProvider, AuthContext, createAuthConfig } from './src/react-native/AuthContext';
export { useAuth } from './src/react-native/useAuth';
export { withAuth } from './src/react-native/withAuth';
export { default as LoginScreen } from './src/react-native/LoginScreen';
export { SocialButton } from './src/react-native/SocialButton';
