# @alphinium/auth

Unified auth package for [alphinium-app](https://github.com/redsitesoftware/alphinium-app) and any forge-generated project.

Provides:
- `AuthProvider` + `AuthContext` — React Context wrapping Strapi JWT auth
- `useAuth()` — hook to access user, token, loading, login/logout
- `withAuth(Component)` — HOC that guards any screen or component
- `LoginScreen` — drop-in full-screen social login UI (GitHub, Google + extensible)
- `SocialButton` — standalone social login button component
- `@alphinium/auth/server` — `validateStrapiJwt()` and Express middleware for Node.js services

---

## Installation

```bash
npm install @alphinium/auth
# peer deps (already in alphinium-app template):
npm install @react-native-async-storage/async-storage react-native-webview
```

---

## React Native Usage

### 1. Wrap your app

```jsx
import { AuthProvider } from '@alphinium/auth';

export default function App() {
  return (
    <AuthProvider strapiUrl="https://auth.alphinium.io">
      <YourNavigator />
    </AuthProvider>
  );
}
```

### 2. useAuth in any component

```jsx
import { useAuth } from '@alphinium/auth';

function ProfileButton() {
  const { user, isAuthenticated, logout, loading } = useAuth();

  if (loading) return null;
  if (!isAuthenticated) return <LoginButton />;

  return (
    <View>
      <Text>Hello {user.username}</Text>
      <Button title="Sign out" onPress={logout} />
    </View>
  );
}
```

### 3. Protect a screen with withAuth

```jsx
import { withAuth } from '@alphinium/auth';
import LoginScreen from './screens/LoginScreen';

function DashboardScreen() {
  const { user } = useAuth();
  return <Text>Welcome {user.email}</Text>;
}

// Renders LoginScreen if not authenticated, null while loading
export default withAuth(DashboardScreen, LoginScreen);
```

### 4. Drop-in LoginScreen

```jsx
import { LoginScreen } from '@alphinium/auth';

// Minimal — uses defaults (GitHub + Google providers, alphinium theme)
<LoginScreen strapiUrl="https://auth.alphinium.io" appName="My App" navigation={navigation} />

// Custom providers and theme
<LoginScreen
  strapiUrl="https://auth.alphinium.io"
  providers={[
    { id: 'google', label: 'Continue with Google', emoji: '🔵', bg: '#4285F4', border: '#3367D6' },
  ]}
  theme={{ primary: '#FF6B35', background: '#1A1A1A' }}
  onLoginSuccess={(token) => console.log('Logged in!', token)}
/>
```

---

## Server Usage (Node.js)

```js
const { validateStrapiJwt, createStrapiAuthMiddleware } = require('@alphinium/auth/server');

// One-off validation
const user = await validateStrapiJwt(token, { strapiUrl: 'https://auth.alphinium.io' });
console.log(user.email);

// Express middleware
const requireAuth = createStrapiAuthMiddleware({ strapiUrl: process.env.STRAPI_URL });

router.get('/me', requireAuth, (req, res) => {
  res.json(req.alphiniumUser); // { id, email, username, … }
});
```

### Options for `validateStrapiJwt`

| Option | Default | Description |
|--------|---------|-------------|
| `strapiUrl` | `process.env.STRAPI_URL \|\| 'https://auth.alphinium.io'` | Strapi base URL |
| `cacheTtlMs` | `30000` | JWT cache TTL in milliseconds |
| `bypassCache` | `false` | Skip the in-memory cache |

---

## Admin / Operator Access

`useAuth()` exposes `isAdmin` — this is **only** `true` if the user object from your custom `validateToken` callback sets `isAdmin: true`. It is **not** derived from Strapi roles.

### Why not Strapi roles?

In an alphinium forge project, Strapi roles belong to the **end-users of the forked app** — completely separate from who the alphinium platform operator is. Using Strapi's `role.name === 'Admin'` check would mean any end-user promoted to Strapi Admin could access developer-facing screens.

### Correct pattern for forge projects

Admin/operator access in **alphinium-app** is gated by `EXPO_PUBLIC_ADMIN_EMAILS` — an env var set at build time by the project operator (the alphinium platform user). See [`src/utils/admin.js`](https://github.com/redsitesoftware/alphinium-app/blob/main/react-native/src/utils/admin.js) in alphinium-app.

```js
// In alphinium-app (not in this package)
import { isProjectAdmin } from '../utils/admin';
const { user } = useAuth();
if (isProjectAdmin(user)) { /* show developer-only UI */ }
```

If you're building a **non-forge app** that genuinely needs role-based admin detection, use a custom `validateToken` prop and return `isAdmin: true` from your own backend:

```jsx
<AuthProvider
  validateToken={async (token) => {
    const res = await fetch('https://myapi.com/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json(); // include isAdmin: true in response for admin users
  }}
>
```

---

## Integration with alphinium-app

The alphinium-app template ships with its own `AuthContext.js` and `LoginScreen.js`. To migrate to `@alphinium/auth`:

1. Replace `import { AuthProvider } from './src/context/AuthContext'` with `import { AuthProvider } from '@alphinium/auth'`
2. Add `strapiUrl={STRAPI_URL}` prop to `<AuthProvider>`
3. Remove `src/context/AuthContext.js` and `src/hooks/useAuth.js` (now provided by this package)

---

## Roadmap

- [ ] Email/password login (Strapi local provider)
- [ ] Token refresh (Strapi `/api/auth/local/refresh`)
- [ ] Social login without WebView (Expo AuthSession / deep link flow)
- [ ] Integration tests with Strapi test instance

See [issue #1](https://github.com/redsitesoftware/alphinium-auth/issues/1) for full spec.
