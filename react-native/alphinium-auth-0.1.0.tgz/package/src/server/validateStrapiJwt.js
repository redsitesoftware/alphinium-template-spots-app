'use strict';

/**
 * validateStrapiJwt — validate a Strapi JWT by calling /api/users/me.
 *
 * Includes an in-memory cache (30 s TTL) so repeated calls within a request
 * lifecycle don't hit Strapi on every middleware invocation.
 *
 * Originally from chatinstance-api/src/middleware/adminAuth.js — extracted
 * here so any alphinium service can share it without copying the code.
 */

const https = require('https');

// jwt → { user, expiresAt }
const jwtCache = new Map();
const CACHE_TTL_MS = 30_000;

/**
 * fetchStrapiUser — raw HTTP request to Strapi /api/users/me.
 * Uses Node's built-in https to keep this module dependency-free.
 */
function fetchStrapiUser(jwt, strapiUrl) {
  return new Promise((resolve, reject) => {
    const url = new URL('/api/users/me', strapiUrl);
    const opts = {
      hostname: url.hostname,
      port: url.port || 443,
      path: url.pathname,
      method: 'GET',
      headers: { Authorization: `Bearer ${jwt}` },
    };

    const req = https.request(opts, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          if (res.statusCode === 200 && data.email) {
            resolve(data);
          } else {
            reject(new Error(`Strapi responded ${res.statusCode}: ${data?.error?.message || body}`));
          }
        } catch {
          reject(new Error('Strapi returned non-JSON response'));
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(5000, () => {
      req.destroy();
      reject(new Error('Strapi JWT validation timed out after 5 s'));
    });
    req.end();
  });
}

/**
 * validateStrapiJwt(jwt, options) — resolve to Strapi user or throw.
 *
 * Options:
 *   strapiUrl   {string}  Base URL of Strapi (default: process.env.STRAPI_URL)
 *   cacheTtlMs  {number}  Cache TTL in ms (default: 30_000)
 *   bypassCache {boolean} Skip cache (default: false)
 *
 * Returns the Strapi user object: { id, email, username, … }
 * Throws on invalid JWT, network error, or Strapi error.
 */
async function validateStrapiJwt(jwt, options = {}) {
  const {
    strapiUrl = process.env.STRAPI_URL || 'https://auth.alphinium.io',
    cacheTtlMs = CACHE_TTL_MS,
    bypassCache = false,
  } = options;

  if (!jwt) throw new Error('validateStrapiJwt: jwt is required');

  const cacheKey = `${strapiUrl}:${jwt}`;
  if (!bypassCache) {
    const cached = jwtCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) return cached.user;
  }

  const user = await fetchStrapiUser(jwt, strapiUrl);
  jwtCache.set(cacheKey, { user, expiresAt: Date.now() + cacheTtlMs });
  return user;
}

/**
 * createStrapiAuthMiddleware(options) — Express/Connect middleware factory.
 *
 * Reads Authorization: Bearer <token> from req.headers,
 * validates against Strapi, and sets req.alphiniumUser.
 *
 * Options: same as validateStrapiJwt options.
 *
 * Usage:
 *   const requireAuth = createStrapiAuthMiddleware({ strapiUrl: '...' });
 *   router.get('/me', requireAuth, (req, res) => res.json(req.alphiniumUser));
 */
function createStrapiAuthMiddleware(options = {}) {
  return async function strapiAuthMiddleware(req, res, next) {
    const authHeader = req.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized', message: 'Missing Bearer token' });
    }

    const jwt = authHeader.slice(7).trim();
    try {
      const user = await validateStrapiJwt(jwt, options);
      req.alphiniumUser = user;
      return next();
    } catch (err) {
      return res.status(401).json({ error: 'Unauthorized', message: err.message });
    }
  };
}

/**
 * clearJwtCache — useful in tests or after logout events.
 */
function clearJwtCache() {
  jwtCache.clear();
}

module.exports = { validateStrapiJwt, createStrapiAuthMiddleware, clearJwtCache };
