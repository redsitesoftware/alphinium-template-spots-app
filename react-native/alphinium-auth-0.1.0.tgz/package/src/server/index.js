/**
 * @alphinium/auth/server — server-side JWT validation utilities.
 *
 * Usage (Node.js / Express / any server):
 *
 *   const { validateStrapiJwt, createStrapiAuthMiddleware } = require('@alphinium/auth/server');
 *
 *   // One-off validation:
 *   const user = await validateStrapiJwt(token, { strapiUrl: 'https://auth.alphinium.io' });
 *
 *   // Express middleware:
 *   const requireAuth = createStrapiAuthMiddleware({ strapiUrl: process.env.STRAPI_URL });
 *   app.use('/protected', requireAuth, myRouter);
 */

module.exports = require('./validateStrapiJwt');
