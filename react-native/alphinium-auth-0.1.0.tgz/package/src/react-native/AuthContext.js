import React, { createContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const AuthContext = createContext(null);

const DEFAULT_CONFIG = {
  strapiUrl: '',
  tokenKey: 'alphinium_auth_token',
};

/**
 * createAuthConfig — merge user config with defaults.
 */
export function createAuthConfig(overrides = {}) {
  return { ...DEFAULT_CONFIG, ...overrides };
}

/**
 * AuthProvider — wraps your app and provides auth state to all children.
 *
 * Props:
 *   strapiUrl       {string}    Strapi instance URL (e.g. "https://auth.alphinium.io")
 *   tokenKey        {string}    AsyncStorage key for the JWT (default: "alphinium_auth_token")
 *   validateToken   {function}  Optional. async (token) => userObject | null
 *                               Override Strapi /api/users/me for non-Strapi backends.
 *                               Return user object on success, null/throw on failure.
 *   children        {node}
 *
 * Context value:
 *   user            — raw user object from Strapi or validateToken
 *   token           — current JWT string
 *   loading         — true while restoring session from storage
 *   error           — last auth error message
 *   isAuthenticated — true when token + user are both present
 *   isAdmin         — true if user.isAdmin === true (set by custom validateToken backends)
 *                     For alphinium-app forge projects, admin access is controlled by
 *                     EXPO_PUBLIC_ADMIN_EMAILS env var — see src/utils/admin.js
 *   login(token)    — store token + fetch profile
 *   logout()        — clear session
 *   clearError()    — reset error state
 */
export function AuthProvider({ strapiUrl, tokenKey = DEFAULT_CONFIG.tokenKey, validateToken, children }) {
  const [user, setUser]       = useState(null);
  const [token, setToken]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(() => { loadStoredAuth(); }, []);

  async function fetchUserProfile(authToken) {
    if (validateToken) {
      const userData = await validateToken(authToken);
      if (!userData) throw new Error('alphinium-auth: token validation failed');
      return userData;
    }
    if (!strapiUrl) throw new Error('alphinium-auth: strapiUrl is required on <AuthProvider> (or provide a validateToken callback)');
    const response = await fetch(`${strapiUrl}/api/users/me`, {
      headers: { Authorization: `Bearer ${authToken}` },
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body?.error?.message || `Strapi ${response.status}`);
    }
    return response.json();
  }

  async function loadStoredAuth() {
    try {
      const storedToken = await AsyncStorage.getItem(tokenKey);
      if (storedToken) {
        const userData = await fetchUserProfile(storedToken);
        setToken(storedToken);
        setUser(userData);
      }
    } catch (err) {
      await AsyncStorage.removeItem(tokenKey);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  const login = useCallback(async (authToken) => {
    setError(null);
    try {
      await AsyncStorage.setItem(tokenKey, authToken);
      const userData = await fetchUserProfile(authToken);
      setToken(authToken);
      setUser(userData);
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [tokenKey, strapiUrl, validateToken]);

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(tokenKey);
    setToken(null);
    setUser(null);
    setError(null);
  }, [tokenKey]);

  const clearError = useCallback(() => setError(null), []);

  return (
    <AuthContext.Provider value={{
      user,
      token,
      loading,
      error,
      isAuthenticated: !!token && !!user,
      isAdmin: user?.isAdmin === true, // only for custom backends that set this flag
      login,
      logout,
      clearError,
    }}>
      {children}
    </AuthContext.Provider>
  );
}
