import { useContext } from 'react';
import { AuthContext } from './AuthContext';

/**
 * useAuth — access auth state and actions from any component inside <AuthProvider>.
 *
 * Returns:
 *   user            {object|null}   Strapi user object (id, email, username, …)
 *   token           {string|null}   JWT token
 *   loading         {boolean}       true while restoring session from AsyncStorage
 *   error           {string|null}   Last auth error message
 *   isAuthenticated {boolean}       true when user + token are set
 *   login(token)    {function}      Persist token, fetch profile, update state
 *   logout()        {function}      Clear token and user state
 *   clearError()    {function}      Clear error state
 */
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an <AuthProvider>');
  }
  return ctx;
}
