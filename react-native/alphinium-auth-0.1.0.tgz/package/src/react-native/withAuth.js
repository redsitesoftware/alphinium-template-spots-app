import React from 'react';
import { useAuth } from './useAuth';

/**
 * withAuth(Component, FallbackComponent?) — HOC that protects a screen/component.
 *
 * If the user is not authenticated, renders FallbackComponent (or null).
 * If auth is still loading, renders null (prevents flash of protected content).
 *
 * Usage:
 *   export default withAuth(DashboardScreen);
 *   export default withAuth(DashboardScreen, LoginScreen);
 */
export function withAuth(Component, FallbackComponent = null) {
  function ProtectedComponent(props) {
    const { isAuthenticated, loading } = useAuth();

    if (loading) return null;

    if (!isAuthenticated) {
      return FallbackComponent ? <FallbackComponent {...props} /> : null;
    }

    return <Component {...props} />;
  }

  const displayName = Component.displayName || Component.name || 'Component';
  ProtectedComponent.displayName = `withAuth(${displayName})`;

  return ProtectedComponent;
}
