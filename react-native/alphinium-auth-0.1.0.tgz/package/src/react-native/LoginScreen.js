import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Alert, SafeAreaView, StatusBar, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useAuth } from './useAuth';
import { SocialButton } from './SocialButton';

const DEFAULT_PROVIDERS = [
  { id: 'github', label: 'Continue with GitHub', emoji: '🐙', bg: '#24292e', border: '#3d444d' },
  { id: 'google', label: 'Continue with Google', emoji: '🔵', bg: '#4285F4', border: '#3367D6' },
];

const DEFAULT_THEME = {
  background: '#0F0F1A',
  surface: '#1A1A2E',
  surfaceBorder: '#2E2E4A',
  primary: '#6C63FF',
  textPrimary: '#FFFFFF',
  textSecondary: '#A0A0C0',
  textMuted: '#606080',
  error: '#FF4D6D',
  divider: 'rgba(255,255,255,0.07)',
};

/**
 * LoginScreen — full-screen social OAuth login UI.
 *
 * Props:
 *   strapiUrl         {string}    Base URL of Strapi (e.g. "https://auth.alphinium.io")
 *   appName           {string}    Shown as app branding (default: "alphinium")
 *   providers         {array}     Override default provider list
 *   theme             {object}    Partial theme overrides (merged with DEFAULT_THEME)
 *   navigation        {object}    React Navigation prop (optional)
 *   onLoginSuccess    {function}  Called with (token) after successful OAuth
 *
 * Note: requires react-native-webview as a peer dependency for OAuth flow.
 */
export default function LoginScreen({
  strapiUrl,
  appName = 'alphinium',
  providers = DEFAULT_PROVIDERS,
  theme: themeOverrides = {},
  navigation,
  onLoginSuccess,
}) {
  const { login } = useAuth();
  const theme = { ...DEFAULT_THEME, ...themeOverrides };

  const [showWebView, setShowWebView] = useState(false);
  const [oauthUrl, setOauthUrl] = useState('');

  // Lazy-load WebView so the package works even without react-native-webview
  let WebView = null;
  try {
    WebView = require('react-native-webview').WebView;
  } catch {
    // Optional peer dep not installed
  }

  function handleSocialLogin(providerId) {
    if (!strapiUrl) {
      Alert.alert('Not configured', 'strapiUrl is required on <AuthProvider> or <LoginScreen>.');
      return;
    }
    if (!WebView) {
      Alert.alert(
        'Missing dependency',
        'Install react-native-webview to enable OAuth login.',
      );
      return;
    }
    setOauthUrl(`${strapiUrl}/api/connect/${providerId}`);
    setShowWebView(true);
  }

  function handleNavigationStateChange(navState) {
    const url = navState.url;
    if (url.includes('/auth/success') || url.includes('access_token=')) {
      try {
        const token = new URL(url).searchParams.get('access_token');
        if (token) {
          login?.(token);
          onLoginSuccess?.(token);
          setShowWebView(false);
          navigation?.goBack();
        }
      } catch (e) {
        console.error('@alphinium/auth: OAuth callback parse error', e);
      }
    } else if (url.includes('/auth/failure') || url.includes('error=')) {
      setShowWebView(false);
      Alert.alert('Login Failed', 'Please try again.');
    }
  }

  if (showWebView && WebView) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: theme.background }}>
        <TouchableOpacity
          style={[styles.webviewClose, { borderBottomColor: theme.divider }]}
          onPress={() => setShowWebView(false)}
        >
          <Text style={[styles.webviewCloseText, { color: theme.error }]}>✕ Cancel</Text>
        </TouchableOpacity>
        <WebView
          source={{ uri: oauthUrl }}
          onNavigationStateChange={handleNavigationStateChange}
          onError={() => {
            setShowWebView(false);
            Alert.alert('Login failed', 'Please try again.');
          }}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.background }]}>
      <StatusBar barStyle="light-content" backgroundColor={theme.background} />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.container}>
          {navigation?.canGoBack?.() && (
            <TouchableOpacity style={styles.back} onPress={() => navigation.goBack()}>
              <Text style={[styles.backText, { color: theme.primary }]}>‹ Back</Text>
            </TouchableOpacity>
          )}

          <View style={styles.brand}>
            <View style={[styles.logoCircle, { backgroundColor: theme.primary }]}>
              <Text style={styles.logoEmoji}>⚡</Text>
            </View>
            <Text style={[styles.appName, { color: theme.textPrimary }]}>{appName}</Text>
            <Text style={[styles.tagline, { color: theme.textSecondary }]}>Sign in to continue</Text>
          </View>

          <View style={styles.buttons}>
            {providers.map((provider) => (
              <SocialButton
                key={provider.id}
                {...provider}
                onPress={handleSocialLogin}
              />
            ))}

            <View style={styles.divider}>
              <View style={[styles.dividerLine, { backgroundColor: theme.divider }]} />
              <Text style={[styles.dividerText, { color: theme.textMuted }]}>or</Text>
              <View style={[styles.dividerLine, { backgroundColor: theme.divider }]} />
            </View>

            <TouchableOpacity
              style={[styles.emailBtn, { borderColor: theme.surfaceBorder, backgroundColor: theme.surface }]}
              onPress={() => Alert.alert('Coming soon', 'Email/password login will be added in a future update.')}
              activeOpacity={0.75}
            >
              <Text style={[styles.emailBtnText, { color: theme.textPrimary }]}>✉️  Sign in with Email</Text>
            </TouchableOpacity>
          </View>

          <Text style={[styles.terms, { color: theme.textMuted }]}>
            By signing in you agree to our{' '}
            <Text style={[styles.termsLink, { color: theme.primary }]}>Terms of Service</Text>
            {' '}and{' '}
            <Text style={[styles.termsLink, { color: theme.primary }]}>Privacy Policy</Text>
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  flex: { flex: 1 },
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingVertical: 32,
    justifyContent: 'center',
  },
  back: { position: 'absolute', top: 24, left: 24 },
  backText: { fontSize: 15, fontWeight: '600' },
  brand: { alignItems: 'center', marginBottom: 40 },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    shadowColor: '#6C63FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 6,
  },
  logoEmoji: { fontSize: 38 },
  appName: { fontSize: 28, fontWeight: '800', marginBottom: 4 },
  tagline: { fontSize: 15 },
  buttons: { gap: 12 },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
    gap: 12,
  },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: 13 },
  emailBtn: {
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
  },
  emailBtnText: { fontSize: 15, fontWeight: '500' },
  terms: { fontSize: 11, textAlign: 'center', marginTop: 32, lineHeight: 18 },
  termsLink: {},
  webviewClose: { padding: 16, paddingHorizontal: 24, borderBottomWidth: 1 },
  webviewCloseText: { fontSize: 15, fontWeight: '600' },
});
