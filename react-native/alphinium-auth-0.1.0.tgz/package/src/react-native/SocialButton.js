import React from 'react';
import { TouchableOpacity, Text, StyleSheet, Platform } from 'react-native';

/**
 * SocialButton — a single social/OAuth provider login button.
 *
 * Props:
 *   provider  {string}    Provider ID matching Strapi OAuth route (e.g. 'github', 'google')
 *   label     {string}    Button label
 *   emoji     {string}    Emoji icon
 *   bg        {string}    Background colour
 *   border    {string}    Border colour
 *   onPress   {function}  Called with (provider) when tapped
 *   style     {object}    Extra style overrides for the button
 */
export function SocialButton({ provider, label, emoji, bg, border, onPress, style }) {
  return (
    <TouchableOpacity
      style={[styles.button, { backgroundColor: bg, borderColor: border }, style]}
      onPress={() => onPress?.(provider)}
      activeOpacity={0.85}
      accessibilityRole="button"
      accessibilityLabel={label}
    >
      {emoji ? <Text style={styles.emoji}>{emoji}</Text> : null}
      <Text style={styles.label}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    gap: 8,
    elevation: 2,
    ...Platform.select({
      web: { boxShadow: '0px 1px 3px rgba(0,0,0,0.2)' },
      default: { shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.2, shadowRadius: 3 },
    }),
  },
  emoji: { fontSize: 20 },
  label: { color: '#fff', fontSize: 15, fontWeight: '600' },
});
